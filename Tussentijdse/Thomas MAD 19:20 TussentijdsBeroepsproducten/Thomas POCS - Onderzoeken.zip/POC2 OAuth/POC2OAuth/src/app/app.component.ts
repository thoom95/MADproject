import { Component } from '@angular/core';
import {Http, RequestOptionsArgs} from '@angular/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'POC2OAuth';
  clientID = 'a003f53cebd94666806fad0c0692d1ee';
  clientSecret = 'b56a727881e04b84b178d2bc6263eb43';

  //   options: https.RequestOptions = {
  //   method: 'POST',
  //   url: 'https://oauth.fatsecret.com/connect/token',
  //   headers: { 'content-type': 'application/json' },
  //   form: {
  //     grant_type: 'client_credentials',
  //     scope: 'basic'
  //   },
  //   json: true
  // };

   options2 = {
    hostname: 'whatever.com',
    port: 443,
    path: '/todos',
    method: 'GET'
  };
  constructor(private http: Http){
    const req = http.request(this.options2, (res) => {
      console.log('statusCode:', res.statusCode);
      console.log('headers:', res.headers);
  
      res.on('data', (d) => {
        process.stdout.write(d);
      });
    });
  
    req.on('error', (e) => {
      console.error(e);
    });
  req.end();
  }

}
