//
//  SecondViewController.swift
//  POC1-UI-In-Swift
//
//  Created by Thomas Muller on 13/11/2019.
//  Copyright © 2019 Thomas Muller. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

